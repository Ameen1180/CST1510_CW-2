import streamlit as st

st.set_page_config(page_title="Week9 Dashboard", layout="wide")

st.title("Week 9 - Streamlit Dashboard")
st.write("If you see this, Streamlit is working")